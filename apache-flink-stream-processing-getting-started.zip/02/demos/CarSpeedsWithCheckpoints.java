import org.apache.flink.api.common.functions.*;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.state.*;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.runtime.state.filesystem.FsStateBackend;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.util.Collector;

public class CarSpeedsWithCheckpoints {

    public static void main(String[] args) throws Exception {
        final ParameterTool params = ParameterTool.fromArgs(args);

        final StreamExecutionEnvironment env =
                StreamExecutionEnvironment.getExecutionEnvironment();

        env.getConfig().setGlobalJobParameters(params);

        env.enableCheckpointing(1000);

        env.getCheckpointConfig().setCheckpointingMode(
                CheckpointingMode.EXACTLY_ONCE);

        env.getCheckpointConfig().setMaxConcurrentCheckpoints(1);

        env.setStateBackend(new FsStateBackend("file:///tmp/flink/checkpoints"));

        env.setRestartStrategy(RestartStrategies.fixedDelayRestart(
                2, // number of restart attempts
                2000 // time in milliseconds between restarts
        ));

        DataStream<String> dataStream = StreamUtil.getDataStream(env, params);
        if (dataStream == null) {
            System.exit(1);
            return;
        }

        DataStream<String> averageViewStream = dataStream
                .map(new Speed())
                .keyBy(0)
                .flatMap(new AverageSpeed());

        averageViewStream.print();

        env.execute("Car Speeds");
    }



    public static class Speed implements MapFunction<String, Tuple2<Integer, Double>> {

        public Tuple2<Integer, Double> map(String row)
                throws Exception {
            try {
                return Tuple2.of(1, Double.parseDouble(row));
            } catch (Exception ex) {
                System.out.println(ex);
            }

            return null;
        }
    }

    public static class AverageSpeed
            extends RichFlatMapFunction<Tuple2<Integer, Double>, String> {

        private transient ValueState<Tuple2<Integer, Double>> countSum;

        public void flatMap(Tuple2<Integer, Double> input, Collector<String> out)
                throws Exception {

            // access the state value
            Tuple2<Integer, Double> currentCountSum = countSum.value();

            // Print out the message if the car exceeds the speed limit
            if (input.f1 >= 65) {
                out.collect(String.format(
                        "EXCEEDED! The average speed of the last %s "
                                + "car(s) was %s, your speed is %s",
                        currentCountSum.f0,
                        currentCountSum.f1 / currentCountSum.f0,
                        input.f1));
                countSum.clear();
                currentCountSum = countSum.value();
            } else {
                out.collect("Thank you for staying under the speed limit!");
            }

            // update the count
            currentCountSum.f0 += 1;

            // add the current speed of the car
            currentCountSum.f1 += input.f1;

            // update the state
            countSum.update(currentCountSum);
        }

        public void open(Configuration config) {
            ValueStateDescriptor<Tuple2<Integer, Double>> descriptor =
                    new ValueStateDescriptor<Tuple2<Integer, Double>>(
                            // the state name
                            "carAverageSpeed",
                            // type information
                            TypeInformation.of(
                                    new TypeHint<Tuple2<Integer, Double>>() { }),
                            // default value of the state, if nothing was set
                            Tuple2.of(0, 0.0));
            countSum = getRuntimeContext().getState(descriptor);
        }
    }
}
